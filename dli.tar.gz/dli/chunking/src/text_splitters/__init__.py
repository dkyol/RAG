from text_splitters.paragraph import extract_paragraphs
from text_splitters.sentence import extract_sentences

__all__ = ["extract_paragraphs", "extract_sentences"]
