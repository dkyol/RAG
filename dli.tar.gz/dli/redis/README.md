Use Redis as Vector DB

Do not need to build image, because using the ready-built image:
`redis/redis-stack:latest`