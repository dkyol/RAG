
def empty(x):
    return x is None or x == ""